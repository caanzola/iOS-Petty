//
//  ThirdViewController.swift
//  Petty
//
//  Created by CAMILO ANDRES ANZOLA GONZALEZ on 2/21/19.
//  Copyright © 2019 CAMILO ANDRES ANZOLA GONZALEZ. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    let alertService = AlertService()
    
    // todo lo de juguetes
    @IBOutlet weak var juguetesButton: UIButton!
    
    @IBAction func didTapJuguetes() {
        
        let alertVC = alertService.alert(title: "Petty esta en proceso de desarrollo", body: "Seguimos trabajando para brindarte todos nuestros servicios, próximamente podrás acceder a este servicio", buttonTitle: "Entendido") {
            
        }
        
        present(alertVC, animated: true)
    }
    
    // todo lo de casas
    
 
    @IBOutlet weak var casasButton: UIButton!
    
    @IBAction func didTapCasas() {
        let alertVC = alertService.alert(title: "Petty esta en proceso de desarrollo", body: "Seguimos trabajando para brindarte todos nuestros servicios, próximamente podrás acceder a este servicio", buttonTitle: "Entendido") {
            
        }
        
        present(alertVC, animated: true)
    }
    
    
    // todo lo de collares
    
    @IBOutlet weak var collaresButton: UIButton!
    
    @IBAction func didTapCollares() {
        let alertVC = alertService.alert(title: "Petty esta en proceso de desarrollo", body: "Seguimos trabajando para brindarte todos nuestros servicios, próximamente podrás acceder a este servicio", buttonTitle: "Entendido") {
            
        }
        
        present(alertVC, animated: true)
    }
    
    // todo lo de snacks
    
    @IBOutlet weak var snacksButton: UIButton!
    
    
    @IBAction func didTapSnacks() {
        let alertVC = alertService.alert(title: "Petty esta en proceso de desarrollo", body: "Seguimos trabajando para brindarte todos nuestros servicios, próximamente podrás acceder a este servicio", buttonTitle: "Entendido") {
            
        }
        
        present(alertVC, animated: true)
    }
    
    // todo lo de accesorios
    
    
    @IBOutlet weak var accesoriosButton: UIButton!
    
    @IBAction func didTapAccesorios() {
        let alertVC = alertService.alert(title: "Petty esta en proceso de desarrollo", body: "Seguimos trabajando para brindarte todos nuestros servicios, próximamente podrás acceder a este servicio", buttonTitle: "Entendido") {
            
        }
        
        present(alertVC, animated: true)
        
    }
    
    // todo lo de otros
    
    
    @IBAction func didTapOtros() {
        let alertVC = alertService.alert(title: "Petty esta en proceso de desarrollo", body: "Seguimos trabajando para brindarte todos nuestros servicios, próximamente podrás acceder a este servicio", buttonTitle: "Entendido") {
            
        }
        
        present(alertVC, animated: true)
        
    }
    
    
    @IBOutlet weak var otrosButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
